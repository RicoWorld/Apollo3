//*****************************************************************************
//
//! @file deepsleep.c
//!
//! @brief Example demonstrating how to enter deepsleep.
//!
//! This example configures the device to go into a deep sleep mode. Once in
//! sleep mode the device has no ability to wake up. This example is merely to
//! provide the opportunity to measure deepsleep current without interrupts
//! interfering with the measurement.
//!
//! The example begins by printing out a banner annoucement message through
//! the UART, which is then completely disabled for the remainder of execution.
//!
//! Text is output to the UART at 115,200 BAUD, 8 bit, no parity.
//! Please note that text end-of-line is a newline (LF) character only.
//! Therefore, the UART terminal must be set to simulate a CR/LF.
//
//*****************************************************************************

//*****************************************************************************
//
// Copyright (c) 2018, Ambiq Micro
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
// 
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
// 
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from this
// software without specific prior written permission.
// 
// Third party software included in this distribution is subject to the
// additional license terms as defined in the /docs/licenses directory.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// This is part of revision v1.2.12-837-gb0e09d712 of the AmbiqSuite Development Package.
//
//*****************************************************************************

#include "am_mcu_apollo.h"
#include "am_bsp.h"
#include "am_util.h"
#include "SEGGER_RTT.h"                 //RTT header
#include "SEGGER_RTT_Conf.h"        //RTT header
#include "ctimer.h"
#include "i2c_driver.h"

//ams
#include "as7026.h"
#include "globals.h"
#include "rawdata.h"
#include "hrm_app.h"
#include "bpm_app_jsys.h"
#include "agc.h"



#define SWO 1

#define AM_BSP_GPIO_AS7026_INT	32


const am_hal_gpio_pincfg_t g_AS7026_int =
{
    .uFuncSel = 3,
    .eIntDir = AM_HAL_GPIO_PIN_INTDIR_HI2LO,
    .eGPInput = AM_HAL_GPIO_PIN_INPUT_ENABLE,
};


volatile SELLECTED_BIO_APP bio_app_sel;
volatile uint8_t itr_handled =1;

AS7026_CHIP as7024;



void bioapp_appHandler(AS7026_CHIP *p_as7024)
{
   
	if (bio_app_sel.bits.raw == 1)
	{
		rawdata_appHandler(p_as7024);
	}
	if (bio_app_sel.bits.hrm == 1)
	{
		hrm_appHandler(p_as7024);
	}
	if (bio_app_sel.bits.prv == 1)
	{
		
	}
	if (bio_app_sel.bits.gsr == 1)
	{
	}
	if (bio_app_sel.bits.bpm == 1)
	{
		bpm_jsys_appHandler(p_as7024);
	}
    
   
}

void bioapp_irqHandler(AS7026_CHIP *p_as7024)
{
	if (bio_app_sel.bits.raw == 1)
	{
		rawdata_itrHandler(p_as7024, agc_state.agc_element, agc_state.fifo_len);
	}
	if (bio_app_sel.bits.hrm == 1)
	{
		hrm_itrHandler(p_as7024, agc_state.agc_element);
	}
	if (bio_app_sel.bits.prv == 1)
	{
		
	}
	if (bio_app_sel.bits.gsr == 1)
	{
	}
	if (bio_app_sel.bits.bpm == 1)
	{
		bpm_jsys_itrHandler(p_as7024);
	}
}

uint8_t as7024_itrHandler(AS7026_CHIP *as7024)
{
	uint8_t res = as7024_getINTR(as7024);
	if (res == AS7026_ERR_NONE)
	{
		if (as7024->state.intrpt.bits.fifo_threshold)
		{
			res = as7024_getFIFO(as7024);
		}
		if (as7024->state.intrpt.bits.ltf) //LTF
		{
			res = as7024_getLTF1Data(as7024);
		}			
		itr_handled = 1;
	}
    else
	{
		//printf("i2c: %d\r\n", res);
		itr_handled = 0;
	}		
	return res;
}


void bioapp_Init(AS7026_CHIP *p_as7024, SELLECTED_BIO_APP app_sel)
{
	if (app_sel.bits.raw == 1)
	{
		rawdata_appInit(p_as7024);
	}
	if (app_sel.bits.hrm == 1)
	{
		hrm_appInit(p_as7024);
		app_sel.bits.prv == 1 ? prv_Enable() : prv_Disable();
	}
	if (app_sel.bits.gsr == 1)
	{
	}
	if (app_sel.bits.bpm == 1)
	{
		bpm_jsys_appInit(p_as7024);
	}
}


void as7024_Start(void)
{
		as7024_GetADCConf(&as7024);
		as7024_GetSeqConf(&as7024);
		as7024_clrFIFO(&as7024);
		as7024_getLEDSCurrent(&as7024);
    as7024_getPDOFFX(&as7024);
		AGC_resetState(&as7024);
	  as7024_startSequencer(&as7024);
}

void as7024_Stop(void)
{
	as7024_stopSequencer(&as7024);
}

//*****************************************************************************
//
// GPIO ISR
//
//*****************************************************************************
void am_gpio_isr(void)
{
    uint64_t ui64Status;

    //
    // Read and clear the GPIO interrupt status.
    //
    am_hal_gpio_interrupt_status_get(false, &ui64Status);
    am_hal_gpio_interrupt_clear(ui64Status);
    am_hal_gpio_interrupt_service(ui64Status);
}

uint8_t g_int_ret = 0;

void
mt_as7024_int_handler(void)
{
    uint32_t interrupt_state;
	  uint8_t halStat;
	
	  am_hal_gpio_state_read(AM_BSP_GPIO_AS7026_INT, AM_HAL_GPIO_INPUT_READ, &interrupt_state);	
	  g_int_ret = 0;
	  while (0 == interrupt_state)
		{
				halStat = as7024_itrHandler(&as7024);
        if (halStat == 0)
        {
            hrm_itrHandler(&as7024, agc_state.agc_element);
		    AGC(&as7024);
            //all apps and AGC have taken the current adc samples from fifo, reset for next data
            as7024.fifo.samples_count = 0;
            as7024.fifo.newDataIdx = 0;
        }
		    as7024_clrINTR(&as7024);
	      am_hal_gpio_state_read(AM_BSP_GPIO_AS7026_INT, AM_HAL_GPIO_INPUT_READ, &interrupt_state);	
        g_int_ret++;				
		}
}

void
am_gpio_int_init(void)
{

}

void
init_timerA1(void)
{
  //
	// Start a timer to trigger the ADC periodically. This timer won't actually
	// be connected to the ADC (as can be done with Timer 3). Instead, we'll
	// generate interrupts to the CPU, and then use the CPU to trigger the ADC
	// in the CTIMER interrupt handler.
	//
	am_hal_ctimer_config_single(0, AM_HAL_CTIMER_TIMERA,
	                          AM_HAL_CTIMER_HFRC_12KHZ |
	                            AM_HAL_CTIMER_FN_REPEAT |
	                              AM_HAL_CTIMER_INT_ENABLE);

	am_hal_ctimer_int_enable(AM_HAL_CTIMER_INT_TIMERA0);

	am_hal_ctimer_period_set(0, AM_HAL_CTIMER_TIMERA, 11, 0);


	//
	// Start the timer.
	//
	am_hal_ctimer_start(0, AM_HAL_CTIMER_TIMERA);

  NVIC_EnableIRQ(CTIMER_IRQn);

}

static uint32_t time_cnt_ms = 0;
void
am_ctimer_isr(void)
{
	//
	// Clear TimerA0 Interrupt.
	//
	am_hal_ctimer_int_clear(AM_HAL_CTIMER_INT_TIMERA0);
	time_cnt_ms++;
}
uint32_t cnt_time[2];

uint32_t get_systick_count(void)
{
	   return time_cnt_ms;
}
//*****************************************************************************
//
// Main function.
//
//*****************************************************************************
int
main(void)
{   
    //
    // Set the clock frequency.
    //
    am_hal_clkgen_control(AM_HAL_CLKGEN_CONTROL_SYSCLK_MAX, 0);

    //
    // Set the default cache configuration
    //
    am_hal_cachectrl_config(&am_hal_cachectrl_defaults);
    am_hal_cachectrl_enable();
	
		//
    // Configure the board for low power.
    //
    am_bsp_low_power_init();    
            
    am_bsp_itm_printf_enable();
    //
    // Print the banner.
    //
    am_util_stdio_terminal_clear();
    am_util_stdio_printf("G-sensor Example\n");


#ifdef AM_PART_APOLLO
    //
    // Power down all SRAM banks.
    //
    am_hal_mcuctrl_sram_power_set(AM_HAL_MCUCTRL_SRAM_POWER_DOWN_ALL,
                                                                AM_HAL_MCUCTRL_SRAM_POWER_DOWN_ALL);
#endif // AM_PART_APOLLO

#ifdef AM_PART_APOLLO2
#if AM_CMSIS_REGS
    //
    // Turn OFF Flash1
    //
    PWRCTRL->MEMEN_b.FLASH1 = 0;
    while ( PWRCTRL->PWRONSTATUS_b.PD_FLAM1 != 0);

    //
    // Power down SRAM
    //
    PWRCTRL->SRAMPWDINSLEEP_b.SRAMSLEEPPOWERDOWN = PWRCTRL_SRAMPWDINSLEEP_SRAMSLEEPPOWERDOWN_ALLBUTLOWER8K;
#else // AM_CMSIS_REGS
    //
    // Turn OFF Flash1
    //
    AM_BFW(PWRCTRL, MEMEN, FLASH1, 0);
    while (AM_BFR(PWRCTRL, PWRONSTATUS, PD_FLAM1) != 0) {}

    //
    // Power down SRAM
    //
    AM_BFWe(PWRCTRL, SRAMPWDINSLEEP, SRAMSLEEPPOWERDOWN, ALLBUTLOWER8K);
#endif // AM_CMSIS_REGS
#endif // AM_PART_APOLLO2

#ifdef AM_PART_APOLLO3
    //
    // Turn OFF Flash1
    //
    if ( am_hal_pwrctrl_memory_enable(AM_HAL_PWRCTRL_MEM_FLASH_512K) )
    {
        while(1);
    }

    //
    // Power down SRAM
    //
    PWRCTRL->MEMPWDINSLEEP_b.SRAMPWDSLP = PWRCTRL_MEMPWDINSLEEP_SRAMPWDSLP_ALLBUTLOWER32K;
#endif // AM_PART_APOLLO3
		
  	am_hal_gpio_pinconfig(AM_BSP_GPIO_AS7026_ENABLE, g_AM_HAL_GPIO_OUTPUT);
	  am_hal_gpio_state_write(AM_BSP_GPIO_AS7026_ENABLE, AM_HAL_GPIO_OUTPUT_CLEAR);		

		//configure interrupt io
		am_hal_gpio_pinconfig(AM_BSP_GPIO_AS7026_INT, g_AS7026_int);
    am_hal_gpio_interrupt_clear(AM_HAL_GPIO_BIT(AM_BSP_GPIO_AS7026_INT));
		am_hal_gpio_interrupt_register(AM_BSP_GPIO_AS7026_INT, mt_as7024_int_handler);
    am_hal_gpio_interrupt_enable(AM_HAL_GPIO_BIT(AM_BSP_GPIO_AS7026_INT));
    NVIC_EnableIRQ(GPIO_IRQn);	
		
		init_timerA1();
		
	  i2c_driver_device_init();
	
	  am_hal_gpio_state_write(AM_BSP_GPIO_AS7026_ENABLE, AM_HAL_GPIO_OUTPUT_SET);
	
	  am_util_delay_ms(10);
		
	  uint8_t data = 0x3;
	  uint8_t id = 0xEE ;		
	  i2c_driver_device_write(&data,REG_CONTROL,1);
	  i2c_driver_device_read(&id,REG_DEVID,1);
	  am_util_stdio_printf("The ID of AS7026 is %x \n",id);
		
#if 1				
		as7024_setDefaultConfig(&as7024);

		AGC_init(&as7024);
		

		as7024_clrFIFO(&as7024);
		AGC_resetState(&as7024);
    as7024_startSequencer(&as7024);
	  hrm_appInit(&as7024);

    //
    // Enable interrupts to the core.
    //
    am_hal_interrupt_master_enable();

		//bioapp_appHandler(&as7024);
		
#endif		
		uint32_t int_flag=0;
    uint8_t reg_data[100];
	RRD(as7024.chip_id, 0x00, reg_data);
	am_util_stdio_printf("reg 00:%02x\r\n", reg_data[0]);
	
	RRD_m(as7024.chip_id, 0x08, 7, reg_data);
	for (int i = 0; i < 7; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 8+i,reg_data[i]);
	}
	
	RRD(as7024.chip_id, 0x10, reg_data);
	am_util_stdio_printf("reg 10:%02x\r\n", reg_data[0]);

	RRD_m(as7024.chip_id, 0x12, 8, reg_data);	
	for (int i = 0; i < 8; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x12+i,reg_data[i]);
	}
	
	RRD_m(as7024.chip_id, 0x1A, 6, reg_data);	
	for (int i = 0; i < 6; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x1A+i,reg_data[i]);
	}	

    RRD(as7024.chip_id, 0x20, reg_data);	
	am_util_stdio_printf("reg 20:%02x\r\n", reg_data[0]);
    RRD(as7024.chip_id, 0x21, reg_data);	
	am_util_stdio_printf("reg 21:%02x\r\n", reg_data[0]);	
	
	RRD_m(as7024.chip_id, 0x20, 8, reg_data);	
	for (int i = 0; i < 8; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x20+i,reg_data[i]);
	}	
	
	RRD_m(as7024.chip_id, 0x30, 23, reg_data);
	for (int i = 0; i < 23; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x30+i,reg_data[i]);
	}

	RRD_m(as7024.chip_id, 0x50, 18, reg_data);
	for (int i = 0; i < 18; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x50+i,reg_data[i]);
	}	
	
	RRD_m(as7024.chip_id, 0x68, 2, reg_data);
	for (int i = 0; i < 2; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x68+i,reg_data[i]);
	}	

	RRD(as7024.chip_id, 0x70, reg_data);
	am_util_stdio_printf("reg 0x70:%02x\r\n", reg_data[0]);
	
	RRD_m(as7024.chip_id, 0x78, 2, reg_data);
	for (int i = 0; i < 2; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x78+i,reg_data[i]);
	}

	RRD_m(as7024.chip_id, 0x80, 16, reg_data);
	for (int i = 0; i < 16; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x80+i,reg_data[i]);
	}

	RRD_m(as7024.chip_id, 0x91, 2, reg_data);
	for (int i = 0; i < 2; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0x91+i,reg_data[i]);
	}

	RRD_m(as7024.chip_id, 0xC0, 6, reg_data);
	for (int i = 0; i < 6; i++)
	{
	    am_util_stdio_printf("reg %0x:%02x\r\n", 0xC0+i,reg_data[i]);
	}

    while (1)
    {
			hrm_appHandler(&as7024);
			  if (g_int_ret > 0)
				{
					  am_hal_gpio_state_read(AM_BSP_GPIO_AS7026_INT, AM_HAL_GPIO_INPUT_READ, &int_flag);
					  //am_util_stdio_printf("%d ", g_int_ret);
				}
				cnt_time[0] = 0;
//				while(0 == int_flag)
//				{
//					am_hal_gpio_state_read(AM_BSP_GPIO_AS7026_INT, AM_HAL_GPIO_INPUT_READ, &int_flag);
//					cnt_time[0]++;
//					as7024_clrINTR(&as7024);
//					if (cnt_time[0] > 20)
//					{
//						    as7024_getINTR(&as7024);	
//						    am_util_stdio_printf("%x clear fail!\n", as7024.state.intrpt.val);
//						    break;
//					}
//				}
        			
			  //if (itr_handled == 0)
				{
					//am_util_stdio_printf("itrHandler!\n");
					//as7024_itrHandler(&as7024);
				}
//			    cnt_time[0] = time_cnt_ms;
//          am_util_delay_ms(200);
//          cnt_time[1] = time_cnt_ms;
//          am_util_stdio_printf("%d, %d\r\n", cnt_time[1], cnt_time[0]);			
    }   
   
}
