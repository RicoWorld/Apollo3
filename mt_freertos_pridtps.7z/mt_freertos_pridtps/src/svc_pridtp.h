//*****************************************************************************
//
//! @file svc_pridtps.h
//!
//! @brief Private Data Transfer Protocol service definition
//
//*****************************************************************************


#ifndef SVC_PRIDTP_H
#define SVC_PRIDTP_H

#ifdef __cplusplus
extern "C"
{
#endif

//#include "att_api.h"

/*!BASE UUID 00002760-08C2-11E1-9703-0E8AC72EXXXX */
#define ATT_UUID_PRIVATE_BASE               0x2E, 0xC7, 0x8A, 0x0E, 0x73, 0x90, \
                                            0xE1, 0x11, 0xC2, 0x08, 0x60, 0x27, 0x00, 0x00

/*! Macro for building Ambiq UUIDs */
#define ATT_UUID_AMBIQ_BUILD(part)      UINT16_TO_BYTES(part), ATT_UUID_PRIVATE_BASE

/*! Partial pridtp service UUIDs */
#define ATT_UUID_PRIDTP_SERVICE_PART     0x2020

/*! Partial pridtp rx characteristic UUIDs */
#define ATT_UUID_PRIDTP_RX_PART          0x2021

/*! Partial pridtp tx characteristic UUIDs */
#define ATT_UUID_PRIDTP_TX_PART          0x2022


/* Pridtp services */
#define ATT_UUID_PRIDTP_SERVICE          ATT_UUID_AMBIQ_BUILD(ATT_UUID_PRIDTP_SERVICE_PART)

/* Pridtp characteristics */
#define ATT_UUID_PRIDTP_RX               ATT_UUID_AMBIQ_BUILD(ATT_UUID_PRIDTP_RX_PART)
#define ATT_UUID_PRIDTP_TX               ATT_UUID_AMBIQ_BUILD(ATT_UUID_PRIDTP_TX_PART)


// PRIVATE DTP Service
#define PRIDTPS_START_HDL               0x0800//0x300
#define PRIDTPS_END_HDL                 (PRIDTPS_MAX_HDL - 1)


/* PRIDTP Service Handles */
enum
{
  PRIDTP_SVC_HDL = PRIDTPS_START_HDL,    /* PRIDTP service declaration */
  PRIDTPS_RX_CH_HDL,                     /* PRIDTP write command characteristic */ 
  PRIDTPS_RX_HDL,                        /* PRIDTP write command data */
  PRIDTPS_TX_CH_HDL,                     /* PRIDTP notify characteristic */ 
  PRIDTPS_TX_HDL,                        /* PRIDTP notify data */
  PRIDTPS_TX_CH_CCC_HDL,                 /* PRIDTP notify client characteristic configuration */
  PRIDTPS_MAX_HDL
};

void SvcPridtpsAddGroup(void);

void SvcPridtpsCbackRegister(attsReadCback_t readCback, attsWriteCback_t writeCback);

#ifdef __cplusplus
}
#endif

#endif


