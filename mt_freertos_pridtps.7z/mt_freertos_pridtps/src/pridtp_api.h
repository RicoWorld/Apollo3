// ****************************************************************************
//
//  pridtp_api.h
//! @file
//!
//! @brief Ambiq Micro's demonstration of private data transfer profile service.
//!
//! @{
//
// ****************************************************************************

#ifndef PRIDTP_API_H
#define PRIDTP_API_H
#include "wsf_types.h"

#include "wsf_os.h"

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************************************
  Macros
**************************************************************************************************/

#ifndef PRIDTP_CONN_MAX
#define PRIDTP_CONN_MAX                  1
#endif


/*************************************************************************************************/
/*!
 *  \fn     PridtpHandlerInit
 *
 *  \brief  Application handler init function called during system initialization.
 *
 *  \param  handlerID  WSF handler ID.
 *
 *  \return None.
 */
/*************************************************************************************************/
void PridtpHandlerInit(wsfHandlerId_t handlerId);
/*************************************************************************************************/
/*!
 *  \fn     PridtpHandler
 *
 *  \brief  WSF event handler for application.
 *
 *  \param  event   WSF event mask.
 *  \param  pMsg    WSF message.
 *
 *  \return None.
 */
/*************************************************************************************************/
void PridtpHandler(wsfEventMask_t event, wsfMsgHdr_t *pMsg);

/*************************************************************************************************/
/*!
 *  \fn     PridtpStart
 *
 *  \brief  Start the application.
 *
 *  \return None.
 */
/*************************************************************************************************/
void PridtpStart(void);


#ifdef __cplusplus
};
#endif

#endif


