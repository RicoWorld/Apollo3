//*****************************************************************************
//
//! @file mspi_quad_example.c
//! edit by luomengjie
//!
//! @brief Example of the MSPI operation with Quad SPI Flash.and PDM MIC
//!
//! Purpose: This example configures an MSPI connected flash device in Quad mode
//! and performs various operations - verifying the correctness of the same
//! Operations include - Erase, Write, Read, Read using XIP Apperture and XIP.
//!
//|
//!
//! GPIO 11 - PDM DATA
//! GPIO 12 - PDM CLK
//! GPIO 19 - MSPI CE0
//! GPIO 24 - MSPI CLK
//! GPIO 23 - MSPI HOLD
//! GPIO 4  - MSPI WP
//! GPIO 26 - MSPI MISO
//! GPIO 22 - MSPI MOSI
//! GPIO 29 - UART_TX
//! GPIO 28 - UART_RX
//! BOTTON0 - Short Press to start/pause;
//!           Long  Press to Reset Flash,erase all data
//! BOTTON1 - Press to transfer flash data to PC by uart

//*****************************************************************************

//*****************************************************************************
//
// Copyright (c) 2019, Ambiq Micro
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
// 
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
// 
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from this
// software without specific prior written permission.
// 
// Third party software included in this distribution is subject to the
// additional license terms as defined in the /docs/licenses directory.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// This is part of revision 2.2.0 of the AmbiqSuite Development Package.
//
//*****************************************************************************


//#include "am_mcu_apollo.h"
//#include "am_bsp.h"
//#include "am_devices_mspi_flash.h"
//#include "am_util.h"

#ifndef RECORDING_TASK_H
#define RECORDING_TASK_H
#ifdef __cplusplus
extern "C"
{
#endif

#define MSPI_TARGET_ADDRESS     0x40000 // {10bit,6bit,12bit},{block address,page address,column address}
#define MSPI_BUFFER_SIZE        (2*1024+64)  // 8k example buffer size.
#define MSPI_TEST_MODULE         0

#include "freertos_amdtp.h"
#include "am_devices_mspi_flash.h"

extern TaskHandle_t recording_handler;
extern bool power_on;


extern void Recordingtask(void *pvParameters);
extern void RecordingSetup(void);

#ifdef __cplusplus
}
#endif
#endif


