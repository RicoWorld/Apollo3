
#include "am_mcu_apollo.h"
#include "am_util.h"
#include "am_bsp.h"

#include "pridtp_api.h"
#include "pridtps_api.h"

#include "send_pkt_task.h"


SemaphoreHandle_t pkt_xsemaphore;

//bool command = false;

TaskHandle_t send_pkt_handler;
uint32_t g_rand=0;
uint8_t g_pkt[20]={0};
uint8_t g_Flash_Buffer[2112]={0};

void SendPktTaskSetup(void)
{
    am_util_debug_printf("SendPktTaskSetup~~~\r\n");

    pkt_xsemaphore = xSemaphoreCreateBinary();
	
//    for(uint32_t i = 0; i < 2112; i++)
//    {   
//        g_Flash_Buffer[i] = (uint8_t)i;
//    }

    am_devices_mspi_flash_read(0,g_Flash_Buffer,0x40000 ,2112,true);    
}

void SendPktTask(void *pvParameters)
{
    uint32_t ui32CurrentTime = 0, ui32ElapsedTime = 0;
    static uint32_t ui32LastTime = 0;
    uint32_t speed = 0; 
	uint32_t last  = 20;


    while (1)
    {
//        am_util_debug_printf("wait for task~~~\r\n");
      if ((xSemaphoreTake(pkt_xsemaphore, portMAX_DELAY) == pdTRUE) &(power_on == 0) )
      {
	  	
        if(g_rand==2100){last = 12;}
		
		else{last = 20;}
		
        for(uint32_t i=0;i<last;i++)
        {   
          g_pkt[i]= g_Flash_Buffer[i+g_rand];
        }
        speed += 20;

        pridtpsSendNtf(g_pkt,last);
        if(g_rand==2100)
        { 
          g_rand = 0;
          flash_address = flash_address+0x1000;
          am_devices_mspi_flash_read(0,g_Flash_Buffer,flash_address ,2112,true);
          am_util_stdio_printf("Reading the %d blcok ,the %d page\n", flash_address >> 18,((flash_address >> 12) & 0x3F));
        }	
        else{g_rand = g_rand + 20;}

      }
      ui32CurrentTime = xTaskGetTickCount();
      ui32ElapsedTime = ui32CurrentTime - ui32LastTime;
      if ( ui32ElapsedTime > 1000 )
      {
        ui32LastTime = ui32CurrentTime;
        am_util_debug_printf("speed:%d\r\n",speed);
        speed = 0;
      }       
    }
}

