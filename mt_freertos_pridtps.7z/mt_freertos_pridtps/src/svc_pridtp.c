//*****************************************************************************
//
//! @file svc_pridtp.c
//!
//! @brief private data transfer protocol service implementation
//!
//
//*****************************************************************************
#include "wsf_types.h"
#include "att_api.h"
#include "wsf_trace.h"
#include "bstream.h"
#include "svc_ch.h"
#include "svc_cfg.h"
#include "svc_pridtp.h"

/**************************************************************************************************
  Macros
**************************************************************************************************/

/*! Characteristic read permissions */
#ifndef DIS_SEC_PERMIT_READ
#define DIS_SEC_PERMIT_READ SVC_SEC_PERMIT_READ
#endif

/*! Default manufacturer name */
#define DIS_DEFAULT_MFR_NAME        "ARM Ltd."


/*! Default model number */
#define DIS_DEFAULT_MODEL_NUM       "Cordio apollo 3"


/*! Default System ID */
#define DIS_DEFAULT_SYSID           "L5MJ2LXF0X"


/*! Default engineer name */
#define DIS_DEFAULT_SERIAL_NUM      "Luomengjie"


/*! Default model name */
#define DIS_DEFAULT_FW_REV          "Recording Board"


/*! Default flash serial number */
#define DIS_DEFAULT_HW_REV          "GD5F1GQ4xCxIG"


/*! Default PDM microphone */
#define DIS_DEFAULT_SW_REV          "MRA153A"



/**********************************************
Service variables
***********************************************/

/*UUIDs*/
static const uint8_t svcRxUuid[] = {ATT_UUID_PRIDTP_RX};
static const uint8_t svcTxUuid[] = {ATT_UUID_PRIDTP_TX};

/*Private service declartion*/
static const uint8_t pridtpSvc[] = {ATT_UUID_PRIDTP_SERVICE};
//static const uint8_t  pridtpSvc[] = {UINT16_TO_BYTES(ATT_UUID_DEVICE_INFO_SERVICE)};//device infromation
static const uint16_t pridtpLenSvc = sizeof(pridtpSvc);


/*Private RX characteristic declartion*/
static const uint8_t pridtpRxCh[] = {ATT_PROP_WRITE_NO_RSP,UINT16_TO_BYTES(PRIDTPS_RX_HDL),ATT_UUID_PRIDTP_RX};
static const uint16_t pridtpLenRxCh = sizeof(pridtpRxCh);

/*Private TX characteristic declartion*/
static const uint8_t pridtpTxCh[] = {ATT_PROP_NOTIFY,UINT16_TO_BYTES(PRIDTPS_TX_HDL),ATT_UUID_PRIDTP_TX};
static const uint16_t pridtpLenTxCh = sizeof(pridtpTxCh);

/*PRIDTP RX data*/
static const uint8_t pridtpRx[] = {0};
static const uint16_t pridtpLenRx = sizeof(pridtpRx);

/*PRIDTP TX data*/
static const uint8_t pridtpTx[] = {0};
static const uint16_t pridtpLenTx = sizeof(pridtpTx);

/* Proprietary data client characteristic configuration */
static uint8_t pridtpTxChCcc[] = {UINT16_TO_BYTES(0x0000)};
static const uint16_t pridtpLenTxChCcc = sizeof(pridtpTxChCcc);

/*Attribute list for PRIDTP group*/
static const attsAttr_t pridtpList[] = 
{

  /*primary service*/
  {
    attPrimSvcUuid,
    (uint8_t *) pridtpSvc,
    (uint16_t *) &pridtpLenSvc,
    sizeof(pridtpSvc),
    0,
    ATTS_PERMIT_READ
  },
  
  {/*Rx characteristic declaration*/
    attChUuid,
    (uint8_t *) pridtpRxCh,
    (uint16_t *) &pridtpLenRxCh,
    sizeof(pridtpLenRxCh),
    0,
    ATTS_PERMIT_READ 
  },
  
  {/*RX characteristic value declaration*/
    svcRxUuid,
    (uint8_t *) pridtpRx,
    (uint16_t *) &pridtpLenRx,
    ATT_VALUE_MAX_LEN,
    (ATTS_SET_UUID_128 | ATTS_SET_VARIABLE_LEN | ATTS_SET_WRITE_CBACK),
    ATTS_PERMIT_WRITE 
  },
  {/*Tx characteristic declaration*/
    attChUuid,
    (uint8_t *) pridtpTxCh,
    (uint16_t *) &pridtpLenTxCh,
    sizeof(pridtpLenTxCh),
    0,
    ATTS_PERMIT_READ
  },
  {/*TX characteristic value declaration*/
    svcTxUuid,
    (uint8_t *) pridtpTx,
    (uint16_t *) &pridtpLenTx,
    sizeof(pridtpTx),
    0,
    ATTS_PERMIT_READ |ATTS_PERMIT_READ_ENC
  },
  {
    attCliChCfgUuid,
    (uint8_t *) pridtpTxChCcc,
    (uint16_t *) &pridtpLenTxChCcc,
    sizeof(pridtpLenTxChCcc),
    ATTS_SET_CCC,
    (ATTS_PERMIT_READ | ATTS_PERMIT_WRITE )
  },
};

/*pridtp group strcture*/
static attsGroup_t svcPridtpGroup = 
{
  NULL,
  (attsAttr_t *) pridtpList,
  NULL,
  NULL,
  PRIDTPS_START_HDL,
  PRIDTPS_END_HDL
};


/*************************************************************************************************/
/*!
 *  \fn     SvcPridtpsAddGroup
 *        
 *  \brief  Add the services to the attribute server.
 *
 *  \return None.
 */
/*************************************************************************************************/
//be called when initialize attribute server database 
void SvcPridtpsAddGroup(void)
{
  AttsAddGroup(&svcPridtpGroup);
}

/*************************************************************************************************/
/*!
 *  \fn     SvcPridtpsCbackRegister
 *        
 *  \brief  Register callbacks for the service.
 *
 *  \param  readCback   Read callback function.
 *  \param  writeCback  Write callback function.
 *
 *  \return None.
 */
/*************************************************************************************************/
void SvcPridtpsCbackRegister(attsReadCback_t readCback, attsWriteCback_t writeCback)
{
  svcPridtpGroup.readCback = readCback;
  svcPridtpGroup.writeCback = writeCback;
}



