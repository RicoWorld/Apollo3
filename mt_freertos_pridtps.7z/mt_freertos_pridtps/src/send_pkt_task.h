
#ifndef SEND_PKT_TASK_H
#define SEND_PKT_TASK_H
#ifdef __cplusplus
extern "C"
{
#endif
#include "freertos_amdtp.h"
#include "recording_task.h"

extern SemaphoreHandle_t pkt_xsemaphore;
extern TaskHandle_t send_pkt_handler;


extern void SendPktTaskSetup(void);

extern void SendPktTask(void *pvParameters);


#ifdef __cplusplus
}
#endif
#endif
