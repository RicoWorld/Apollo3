#ifndef PRIDTPS_API_H
#define PRIDTPS_API_H

#include "wsf_types.h"
#include "wsf_timer.h"  //include wsf_os.h
#include "att_api.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define PRIDTP_PACKET_SIZE                          512
#define PRIDTP_HEADER_SIZE_IN_PKT                   1  //cmd size

#define ATT_DEFAULT_PAYLOAD_LEN                     20

extern uint32_t flash_address;

/*! Configurable parameters */
typedef struct
{
    //! Short description of each member should go here.
    uint32_t reserved;
}
PridtpsCfg_t;



//*****************************************************************************
//
// function definitions
//
//*****************************************************************************

void pridtps_init(wsfHandlerId_t handlerId, PridtpsCfg_t *pCfg);

void pridtps_proc_msg(wsfMsgHdr_t *pMsg);

uint8_t pridtps_write_cback(dmConnId_t connId, uint16_t handle, uint8_t operation,uint16_t offset, uint16_t len, uint8_t *pValue, attsAttr_t *pAttr);

extern void pridtps_conn_close(dmConnId_t connId);

void pridtps_start(dmConnId_t connId,uint8_t resetTimerEvt,uint8_t pridtpCccIdx);

void pridtps_stop(dmConnId_t connId);

extern void pridtpsSendNtf(uint8_t *pData,uint8_t plen);

#endif

#ifdef __cplusplus
}


#endif


