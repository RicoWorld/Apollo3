
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "wsf_types.h"
#include "wsf_assert.h"
#include "wsf_trace.h"
#include "wsf_buf.h"
#include "bstream.h"
#include "att_api.h"
#include "svc_ch.h"
#include "svc_pridtp.h"   //private service 
#include "app_api.h"
#include "app_hw.h"
#include "pridtps_api.h"
#include "am_util_debug.h"
#include "crc32.h"

#include "am_mcu_apollo.h"
#include "am_bsp.h"
#include "am_util.h"

//#include "oled.h"

//
// pridtp states
//
typedef enum
{
    PRIDTP_STATE_INIT,
    PRIDTP_STATE_GETTING_FW,
    PRIDTP_STATE_MAX
}ePridtpState;

//
// pridtp commands
//
typedef enum
{
    PRIDTP_CMD_UNKNOWN,
    PRIDTP_CMD_FW_HEADER,
    PRIDTP_CMD_FW_DATA,
    PRIDTP_CMD_MAX
}ePridtpCommand;

//
// pridtp status
//
typedef enum 
{
    PRIDTP_STATUS_SUCCESS,
    PRIDTP_STATUS_CRC_ERROR,
    PRIDTP_STATUS_INVALID_METADATA_INFO,
    PRIDTP_STATUS_INVALID_PKT_LENGTH,
    PRIDTP_STATUS_INSUFFICIENT_BUFFER,
    PRIDTP_STATUS_UNKNOWN_ERROR,
    PRIDTP_STATUS_BUSY,
    PRIDTP_STATUS_TX_NOT_READY,              // no connection or tx busy
    PRIDTP_STATUS_RESEND_REPLY,
    PRIDTP_STATUS_RECEIVE_CONTINUE,
    PRIDTP_STATUS_RECEIVE_DONE,
    PRIDTP_STATUS_MAX
}ePridtpStatus;


//
// Connection control block
//
typedef struct
{
    dmConnId_t    connId;               // Connection ID
    bool_t        pridtpToSend;          // PRIDTP notify ready to be sent on this channel
}
pridtpsConn_t;

typedef struct
{
    uint16_t    offset;
    uint16_t    len;                        // data plus checksum
    ePridtpCommand type;
    uint8_t     data[PRIDTP_PACKET_SIZE]  __attribute__((aligned(4)));   // needs to be 32-bit word aligned.
}
pridtpPacket_t;

/* Control block */
static struct
{
    pridtpsConn_t               conn[DM_CONN_MAX];      // connection control block
    bool_t                      txReady;                // TRUE if ready to send notifications
    wsfHandlerId_t              appHandlerId;
    PridtpsCfg_t                cfg;                    // configurable parameters
    ePridtpState                txState;
    ePridtpState                rxState;
    pridtpPacket_t              rxPkt;
    pridtpPacket_t              txPkt;
    wsfTimer_t                  resetTimer;
    uint16_t                    attMtuSize;
}
pridtpsCb;


uint32_t    flash_address = 0x40000; 




//*****************************************************************************
//
// Connection Open event
//
//*****************************************************************************
static void
pridtps_conn_open(dmEvt_t *pMsg)
{
    hciLeConnCmplEvt_t *evt = (hciLeConnCmplEvt_t*) pMsg;
    
    APP_TRACE_INFO0("pridtps_main :connection opened\n");
    APP_TRACE_INFO1("handle = 0x%x\n", evt->handle);
    APP_TRACE_INFO1("role = 0x%x\n", evt->role);
    APP_TRACE_INFO3("addrMSB = %02x%02x%02x%02x%02x%02x\n", evt->peerAddr[0], evt->peerAddr[1], evt->peerAddr[2]);
    APP_TRACE_INFO3("addrLSB = %02x%02x%02x%02x%02x%02x\n", evt->peerAddr[3], evt->peerAddr[4], evt->peerAddr[5]);
    APP_TRACE_INFO1("connInterval = 0x%x\n", evt->connInterval);
    APP_TRACE_INFO1("connLatency = 0x%x\n", evt->connLatency);
    APP_TRACE_INFO1("supTimeout = 0x%x\n", evt->supTimeout);
}

//*****************************************************************************
//
// Connection Update event
//
//*****************************************************************************
static void
pridtps_conn_update(dmEvt_t *pMsg)
{
    hciLeConnUpdateCmplEvt_t *evt = (hciLeConnUpdateCmplEvt_t*) pMsg;

    APP_TRACE_INFO0("pridtps_main :connection updated\n");
    APP_TRACE_INFO1("connection update status = 0x%x", evt->status);
    APP_TRACE_INFO1("handle = 0x%x", evt->handle);
    APP_TRACE_INFO1("connInterval = 0x%x", evt->connInterval);
    APP_TRACE_INFO1("connLatency = 0x%x", evt->connLatency);
    APP_TRACE_INFO1("supTimeout = 0x%x", evt->supTimeout);
}

//*****************************************************************************
//
// Connection Close event
//
//*****************************************************************************
void
pridtps_conn_close(dmConnId_t connId)
{
    //clear connection
    pridtpsCb.conn[connId-1].connId = DM_CONN_ID_NONE;
    pridtpsCb.conn[connId-1].pridtpToSend = FALSE;
    
}

//*****************************************************************************
//
// Pridtps start
//
//********************************************************************
void 
pridtps_start(dmConnId_t connId,uint8_t resetTimerEvt,uint8_t pridtpCccIdx)
{
    pridtpsCb.conn[connId-1].connId = connId;
    pridtpsCb.conn[connId-1].pridtpToSend = TRUE;
    
    pridtpsCb.attMtuSize = AttGetMtu(connId);
    APP_TRACE_INFO1("pridtps_start:MTU size = %d bytes", pridtpsCb.attMtuSize);
    pridtpsCb.resetTimer.msg.event = resetTimerEvt;
}

//*****************************************************************************
//
// Pridtps stop
//
//********************************************************************
void 
pridtps_stop(dmConnId_t connId)
{
    //clear connection
    //pridtpsCb.conn[connId-1].connId = DM_CONN_ID_NONE;
    pridtpsCb.conn[connId-1].connId = DM_CONN_CLOSE_IND;
    pridtpsCb.conn[connId-1].pridtpToSend = FALSE;
}


//*****************************************************************************
//
//! @brief initialize pridtp service
//!
//! @param handlerId - connection handle
//! @param pCfg - configuration parameters
//!
//! @return None
//
//*****************************************************************************
void
pridtps_init(wsfHandlerId_t handlerId, PridtpsCfg_t *pCfg)
{
    memset(&pridtpsCb, 0, sizeof(pridtpsCb));
    pridtpsCb.appHandlerId = handlerId;
    pridtpsCb.txReady = FALSE;
    pridtpsCb.rxState = PRIDTP_STATE_INIT;
    pridtpsCb.resetTimer.handlerId = handlerId;
    for (int i = 0; i < DM_CONN_MAX; i++)
    {
        pridtpsCb.conn[i].connId = DM_CONN_ID_NONE;
    }
}

//*****************************************************************************
//
//! @brief pridtps_write_cback
//!
//! 
//!
//!"reset or RESET"用于复位透传时，读取flash的起始地址"
//
//*****************************************************************************


uint8_t
pridtps_write_cback(dmConnId_t connId, uint16_t handle, uint8_t operation,
                   uint16_t offset, uint16_t len, uint8_t *pValue, attsAttr_t *pAttr)
{
    uint16_t i = 0;
	uint8_t CCAM = 0;

	
	char str1[]="reset";
	char str2[]="RESET";
    APP_TRACE_INFO0("============= data arrived start  ===============");
    APP_TRACE_INFO1("len:%d\t", len);
    for (i = 0; i < len; i++)
    {
      APP_TRACE_INFO1("%x\t", pValue[i]);
	  if((pValue[i]==str1[i]) ||(pValue[i]==str2[i])) { CCAM=CCAM+1;}
    }
	if(CCAM==5)
    { 
      am_util_debug_printf("Current FLASH ADDR:0x%x\r\n",flash_address);
      flash_address = 0x40000;
      APP_TRACE_INFO0("=============RESET FLASH===============");
      am_util_debug_printf("Current FLASH ADDR:0x%x\r\n",flash_address);
    }
    CCAM = 0;
    APP_TRACE_INFO0("");
    APP_TRACE_INFO0("============= data arrived end ===============");
   
//    xStatus = xQueueSend( xCommandQueue, pValue, xTicksToWait );
    for (int i =0; i<len;i++)
    {
      *pValue =0;
       pValue++;
    }
			
    return ATT_SUCCESS;
}

//*****************************************************************************
//
//! @brief initialize amota service
//!
//! @param pMsg - WSF message
//!
//! @return None
//
//*****************************************************************************
void pridtps_proc_msg(wsfMsgHdr_t *pMsg)
{
    if (pMsg->event == DM_CONN_OPEN_IND)
    {
        APP_TRACE_INFO0("pridtps_proc_msg_event :DM_CONN_OPEN_IND\n");
        pridtps_conn_open((dmEvt_t *) pMsg);
    }
    else if (pMsg->event == DM_CONN_UPDATE_IND)
    {
        APP_TRACE_INFO0("pridtps_proc_msg_event :DM_CONN_OPEN_IND\n");
        pridtps_conn_update((dmEvt_t *) pMsg);
    }
}


void pridtpsSendNtf(uint8_t *pData,uint8_t len)
{
    pridtpsConn_t *pConn = pridtpsCb.conn;
    
    /* send notification */
    AttsHandleValueNtf(pConn->connId, PRIDTPS_TX_HDL, len, pData);
    

}
